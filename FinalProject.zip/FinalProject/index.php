<?php
	$page_title = "Pineapple Inc.";
	include ('includes/header.php');
?>
<!DOCTYPE HTML>
<html lang="en-us">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
    <link rel="stylesheet" type="text/css" href="includes/style.css">
    <title></title>
</head>
<body>
<h2 class="p2" style="text-align: center">Welcome to Pineapple Inc.</h2>
<div id="slider"><!-- Defining the main content section -->
    <!-- Promo slider -->
    <section id="slider-wrapper">
        <!-- Flickity HTML init -->
        <div class="slideshow">
            <!-- carousel control buttons -->
            <button class="slide-btn slide-btn-1"></button>
            <button class="slide-btn slide-btn-2"></button>
            <button class="slide-btn slide-btn-3"></button>
            <button class="slide-btn slide-btn-4"></button>
            <!-- carousel wrapper which contains all images -->
            <div class="slideshow-wrapper">
                <div class="slide">
                    <img class="slide-img"
                         src=
                         "https://images.prismic.io/teenageengineering/0019cc38-a796-4cec-b012-b0820b570ef5_computer-1_store_front+%281%29.png?auto=compress,format&w=512&h=1">
                </div>
                <div class="slide">
                    <img class="slide-img"
                         src=
                         "https://images.prismic.io/teenageengineering/0019cc38-a796-4cec-b012-b0820b570ef5_computer-1_store_front+%281%29.png?auto=compress,format&w=1080&h=1">
                </div>
                <div class="slide">
                    <img class="slide-img" src=
                    "https://images.prismic.io/teenageengineering/5f5a139a-fe12-4e6c-bce1-b8a5b484d169_computer-1_store_back.png?auto=compress,format&w=1080&h=1">
                </div>
                <div class="slide">
                    <img class="slide-img" src=
                    "https://images.prismic.io/teenageengineering/d379b4fd-3721-4cd4-bec2-f3a7c13e099f_computer-1_store_layout.png?auto=compress,format&w=1080&h=1">
                </div>
            </div>
        </div>
</div>

        <div id="htmlcaption-1" class="nivo-html-caption">

            <p style="text-align: -webkit-center"> A community for PC builders and modders. A great place to
            find your next affordable rig. </p>
            <p style="text-align: -webkit-center">Our mission is to allow computer enthusiasts no matter expertese levels to allow for a jump start into building their own  personalized PC </p>

    </section>
</div>
<div id="main"><!-- Defining submain content section -->
    <section id="content"><!-- Defining the content section #2 -->
        <div id="left">
            <h3>Products</h3>
            <ul>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post1.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 1</a>
                        <p>long description here 1</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$550.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post2.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 2</a>
                        <p>long description here 2</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$250.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post3.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 3</a>
                        <p>long description here 3</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$350.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post4.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 4</a>
                        <p>long description here 1</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$550.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post5.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 5</a>
                        <p>long description here 2</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$250.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post6.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 6</a>
                        <p>long description here 3</p>
                        <div class="price">
                            <span class="st">Our price:</span><strong>$350.00</strong>
                        </div>
                        <div class="actions">
                            <a href="#">Details</a>
                            <a href="#">Add to cart</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div id="right">
            <h3>Top sellers</h3>
            <ul>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post6.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 7</a>
                        <div class="price">
                            <span class="usual">$600.00 </span>&nbsp;
                            <span class="special">$500.00</span>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post5.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 8</a>
                        <div class="price">
                            <span class="usual">$500.00 </span>&nbsp;
                            <span class="special">$400.00</span>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post4.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 9</a>
                        <div class="price">
                            <span class="usual">$700.00 </span>&nbsp;
                            <span class="special">$600.25</span>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="img"><a href="#"><img alt="" src="images/post3.jpg"></a></div>
                    <div class="info">
                        <a class="title" href="#">The Pineapple 10</a>
                        <div class="price">
                            <span class="usual">$805.00 </span>&nbsp;
                            <span class="special">$714.25</span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>
</div>
</body>
<?php
	include ('includes/footer.php');
?>
</html>
