<?php
    $title = "Pineapple Inc.";
    ?>

<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php $title?></title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="header">
    <a><img src="../www/img/pineapple.jpg" class="logo"/>Pineapple Inc.</a>
    <div class="header-right">
        <a class="active" href="#home">Home</a>
        <a class="#store" href="#store">Specials</a>
        <a href="#contact">All Products</a>
        <a class="#account">Account</a>
        <div class="search-container">
            <form action="/action_page.php">
                <input type="text" placeholder="Search.." name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
    </div>
</div>

</html>
