<footer><!-- Defining the footer section of the page -->
	<div class="header">
        <div class="footer-left">
            <a href="about.php"> About</a>
        </div>
	</div>
</footer>